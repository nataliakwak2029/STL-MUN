# STLMUN Website

A responsive single-page website for St. Laurence High School Model United Nations.

## Files
- `index.html` — complete site, styling, navigation, and content
- `assets/hero.jpg` — cropped STLMUN display photo
- `assets/conference.jpg` — conference team photo
- `assets/team.jpg` — team photo
- `assets/leadership-preview.jpg` — reference image from the supplied Canva screenshot

## Links included
- Instagram: https://www.instagram.com/stl_mun/
- Linktree: https://linktr.ee/stl_mun?utm_source=linktree_profile_share&ltsid=fada2912-4ddf-4089-8ad4-9672580ae966
- School Instagram: https://www.instagram.com/stlvikes/
- Contact: nkwak29@stlaurence.com

Open `index.html` in a browser to view the website.
